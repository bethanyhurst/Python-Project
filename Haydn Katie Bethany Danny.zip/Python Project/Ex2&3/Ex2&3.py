#Python program to take in a username and password, put them in a dictionary then store them in a file then read from that file
####2
userName = input("Enter a username:\n") #Get a username
userPass = input("Enter a password:\n") #Get a password

userData = {userName:userPass} #Put the data into a dictionary
print(userData) #Print the dictionary

with open("userData.txt", "w") as des: #Open the destination file
    des.write(str(userData)) #Write the dictionary as a string - written data needs to be a string

with open("userData.txt") as src: #Open the source file
    data = eval(src.read()) #Read the data into a dictionary
    #eval() evaluates the format to determine it's a dictionary

print(data) #Print the data

####3
from easygui import *
attempts = 3
while attempts > 0:
    userData = multpasswordbox("Enter your login information","Login",["Username","Password"]) #Display GUI
    userName = userData[0] #Take a username
    userPass = userData[1] #Take a password

    if userName in data: #If the entered username is correct
        if data[userName] == userPass: #If the entered password is correct
            print("Correct details.") #Both were right
        else:
            print("Wrong password") #Just the username was right
            attempts -= 1
    else:
        print("Wrong username") #The username was wrong