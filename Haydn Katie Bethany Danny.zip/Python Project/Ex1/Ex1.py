import random #Used to generate a random shift
import string #To get the full alphabet
alphabet = string.ascii_lowercase #Lower case alphabet
alphLen = len(alphabet) #Holds the length of the alphabet
shift = random.randint(1, 25) #Choose a random shift

message = input("Type your message:\n").lower() #Get the message to use
codedMessage = []

for char in message: #Go through each character in the message
    charPos = alphabet.index(char)
    newCharPos = (charPos + shift) % alphLen #Get the shifted position of the character
    codedMessage.append(alphabet[newCharPos]) #Add the shifted character to the ciphertext

print(message + " Shifted " + str(shift) + " characters is " + "".join(codedMessage)) #Print the shifted message