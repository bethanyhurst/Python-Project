##http://easygui.sourceforge.net/tutorial.html - For using easyGUI

from easygui import *
import sys
import hashlib
import string
import random

def genMessage(minLen, maxLen): #Picks a random word between a certain length
    with open("words.txt") as source: #Open the files of passwords
        words = [line.strip() for line in source if len(line) in range(minLen, maxLen)]

    message = random.choice(words)
    return(message)

def showHub(userName): #Hub screen to choose a feature of the program
    functions = [showHangman,showScore,showLogon] #List of the functions to leaunch the different areas of the program
    choices=["Hangman", "Scoreboard", "Log out"] #List of the options given to the user
    selected = indexbox("What do you want to do?", choices=choices) #Display the options to the user and get their chosen one

    if(selected != None): #If the window isn't closed
        functions[selected](userName) #Run the chosen function
    else:
        exit(0) #Exit the program

def hangmanDraw(question, state, numOfAttempts, score): #Updates the image
    attemptsLeft = ("\nYou have " + str(numOfAttempts) + " attempts left")
    scoreCurrent = ("\nYour current score is " + str(score))
    imageCurrent = ("State" + str(state) + ".png")
    userInput = enterbox(msg=question + attemptsLeft + scoreCurrent, title="Hangman quiz", image=imageCurrent)

    if(userInput == None):
        showHub()

    return(userInput)

def showHangman(userName): #Launch hangman
    choice = ("yes")

    while(choice == "yes"): #Loop games until the user wants to stop (this prevents stack overflow vs calling the function again)
        print("Hangman")
        state = 0 #Holds the current state of the image
        score = 0 #Holds the user's score
        qTypes = [caesar, vigenere] #The types of questions available and their function calls

        while(state < 12): #Loop to ask questions
            qType = random.choice(qTypes) #Choose a random type
            state, score = qType(state, score) #Call the function of the question type

        dataExists = logonCheckFirst("Users.txt")
        if(dataExists == True):
            with open("users.txt") as source:
                usersData = eval(source.read())
            if(score > usersData[userName][1]): #If the current score is higher than the high score
                usersData[userName][1] = score #Replace it
                with open("users.txt", "w") as destination:
                    destination.write(str(usersData))

        endMsg = ("Want to play again?")
        choices = ["Yes", "No"]
        choice = buttonbox(msg=endMsg, choices=choices) #Ask if the user wants to play again

    showHub(userName)

def checkAnswer(score, state, question, message, codedMessage, decrypt): #checks all answers
    numOfAttempts = 3

    while numOfAttempts > 0:
        response = hangmanDraw(question,state, numOfAttempts, score)

        if ((decrypt == True and response == message) or (decrypt == False and response == codedMessage)): ####
            print("Well done!")
            score += 1
            break
        else:
            print("Incorrect! Try again.")
            numOfAttempts -= 1

    if (numOfAttempts <= 0):
        print("Too many wrong answers") #No chances left - next question
        state += 1

    return(state, score)

def caesar(state, score): #Caesar question
    alphabet = string.ascii_lowercase #Holds the alphabet
    alphLen = len(alphabet) #Holds the length of the alphabet
    message = genMessage(5, 15)
    question = ("this message, ") + message
    shift = random.randint(1, 25) #Choose a shift
    decrypt = random.choice([True, False]) #Choose encode or decode

    if decrypt == False: #Encode
        shift = shift
        question = ("Encrypt this message, using the caesar cipher, shift ") + str(shift) + ": " +message ####
    else: ####Decode
        shift *= -1 ####
        question = ("Decrypt this message, using the caesar cipher, shift ") + str(shift) ####

    codedMessage = []

    for char in message:

        if char in alphabet:
            charPos = alphabet.index(char)

        newCharPos = (charPos + shift) % alphLen
        codedMessage.append(alphabet[newCharPos])

    if decrypt == True:
        question += (": ") + "".join(codedMessage)

    print(question)
    print(message) ####Shows answers
    print("".join(codedMessage)) ####
    state, score = checkAnswer(score, state, question, message, "".join(codedMessage), decrypt) ####
    return(state, score)

def vigenereTable(): #Function to fill a list with lists of the alphabet with different shifts
    table = []
    for i in range(25): #Make the table have 26 items
        table.append([])

    for row in range(25): #Foor each letter in the alphabet

        for column in range(26):

            if (row + 65) + column > 90:
                # moving back to A after Z
                # after first row, each letter will shift left by one position compared to row above it
                table[row].append(chr((row+65) + column - 26)) #Add the letter to the table
            else:
                # after first row, each letter will shift left by one position compared to row above it
                character = chr((row+65)+column)
                table[row].append(character) #Add the letter to the table

    return table

def vigenereEncryption(message, mappedKey):
    table = vigenereTable() #Get a table of all the shifted alphabets
    codedMessage = ""

    for i in range(len(message)): #For each character in the message

        if message[i] == chr(32): #If the character is a space
            # ignoring space
            codedMessage += " " #Add a space to the ciphertext
        else:
            # getting element at specific index of table
            row = ord(message[i])-65 #The row in the table of the encoded character
            column = ord(mappedKey[i]) - 65 #The column in the table
            codedMessage += table[row][column] #Add the encoded character to the ciphertext

    print(codedMessage) ####Show answer
    return(codedMessage)

def vigenereMessageKey():
    msg = genMessage(5,15).upper() #get a message
    key = genMessage(3,8).upper() #Get a key
    # variable to store mapped key
    keyMap = "" #The key repeated for the same number of characters as the message
    j=0 #Holds the place of the current key character

    for i in range(len(msg)): #Counts through each letter in the message

        if ord(msg[i]) == 32: #ord() gets the unicode code for the character
            #If the current letter is a space
            keyMap += " " #A space lined up with each space in the message
        else:

            if j < len(key): #Count through the letters in the key
                keyMap += key[j] #Add the character to the key map
                j += 1 #Move to next letter
            else:
                j = 0 #Go back to the start of the key
                keyMap += key[j] #Add the character to the key map
                j += 1 #Move to next letter
    #print(keyMap)
    return msg, keyMap, key #Return the obtained values

def vigenere(state, score): #Vigenere question
    decrypt = random.choice([True, False]) #Choose encode or decode
    message, mappedKey, key = vigenereMessageKey() #Get the message and the key
    codedMessage = vigenereEncryption(message, mappedKey) #Encrypt the message

    if decrypt == False: #Encrypt
        question = ("Encrypt the following message, using the vigenere cipher with " + key + " as the key: " + message)

    else: #Decrypt
        question = ("Decrypt the following message, using the vigenere cipher with " + key + " as the key: " + codedMessage)

    print(question)
    state, score = checkAnswer(score, state, question, message, codedMessage,decrypt)
    return(state, score)

def showScore(userName): #Launch the scoreboard
    dataExists = logonCheckFirst("Users.txt")
    scores = []
    users = []

    for i in range(0,10):
        scores.append(0)
        users.append("---")
    print(scores)

    if(dataExists == True):
        with open("users.txt") as source:
            usersData = eval(source.read())

        for key,data in usersData.items():
            print(data[1])

            if(data[1] > scores[0]): #If the current score is greater than the loswest
                scores[0] = data[1] #Replace the lowest score
                scores.sort() #Sort the list of scores
                users[0] = key
                scoreLoc = scores.index(data[1])

                for i in range(0,scoreLoc):
                    pos2 = users[i+1]
                    users[i+1] = users[i]
                    users[i] = pos2

                users[scoreLoc] = key

        scores.sort(reverse=True)
        users.reverse()
    #else:
    msg = ""

    for i in range(0,10):
        msg += "\n"+ users[i] + str(scores[i])

    ok = msgbox(msg, ok_button = "OK")
    if(ok == "OK"):
        showHub(userName)
    print(scores)

def checkNum(char): #Checks if a given string is a number
    try:
        char = int(char) #Try to convert the string into an integer
        return(True)
    except:
        return(False)

def logonCheckFirst(fileName):
    try: #Check if the program has been run before
        reading = open(fileName) #Try to open the accounts file
        dataExists = True #The file exists - the program has been run before
    except:
        dataExists = False #The file doesn't exist - this is the first run of the program
    return(dataExists)

def logonPassStrength(password): #Finds the number of each type of character in the given password
    numChar = 0
    numLet = 0
    numLetUpp = 0
    numLetLow = 0
    numNum = 0
    numSym = 0
    listAlphabet = list(string.ascii_letters)
    listAlphabetLow = list(string.ascii_lowercase)
    listAlphabetUpp = list(string.ascii_uppercase)

    for char in password: #Go through each character in the password
        if(checkNum(char) == True): #If the character is a number
            numNum += 1
        elif(char in listAlphabet): #if the character is a letter
            if(char in listAlphabetLow): #If it is lower case
                numLetLow += 1
            else: #it is upper case
                numLetUpp += 1
            numLet += 1
        else: #It is a symbol
            numSym += 1
        numChar += 1
    return(numChar,numLet,numLetLow,numLetUpp,numNum,numSym)

def logonCreate(): #Allow the user to create an account
    dataExists = logonCheckFirst("Users.txt")
    createHeader = ("Create your account") #Title of the page
    createMsg = ("Enter your chosen username and password.\n" +
    "\nYour password must be 9 characters or longer and contain one or more " +
    "symbol, number, upper case and lower case letter.") #Main message
    createFields = ["Username","Password"] #Entry fields
    createEntries = [] #Results given by the user
    errMsg = ""

    if(dataExists == True):
        with open("users.txt") as source:
            usersData = eval(source.read())
    else:
        usersData = {}

    if(logonCheckFirst("bannedwords.txt") == True):
        with open("bannedwords.txt") as source:
            bannedWords = [line.strip() for line in source]
    else:
        bannedWords = []

    while 1: #Keep asking for entries until entered data is valid
        createEntries = multpasswordbox(createMsg + errMsg, createHeader, createFields) #Display fields and get entries back

        if(createEntries is None): #If cancel is clicked
            sys.exit(0) #Close the program
        else:
            userName = createEntries[0]
            userPass = createEntries[1]
            numChar,numLet,numLetLow,numLetUpp,numNum,numSym = logonPassStrength(userPass)
            bannedWord = False

            for word in bannedWords:
                if(word in userName):
                    bannedWord = True

            if(userPass == ""): #Check validity of entered data
                errMsg = ("\n\nNeed to enter a password.")
            elif(userName == ""):
                errMsg = ("\n\nNeed to enter a username.")
            elif(usersData.__contains__(userName)):
                errMsg = ("\n\nUsername already in use.")
            elif(numChar < 9):
                errMsg = ("\n\nPassword too short")
            elif(numLetLow == 0):
                errMsg = ("\n\nNo lowercase letters in the password.")
            elif(numLetUpp == 0):
                errMsg = ("\n\nNo uppercase letters in the password.")
            elif(numNum == 0):
                errMsg = ("\n\nNo numbers in the password.")
            elif(numSym == 0):
                errMsg = ("\n\nNo symbols in the password.")
            elif(bannedWord == True):
                errMsg = ("\n\nUsername contains a banned word.")
            else: #If all data is valid
                break

    errMsg = ""

    while 1: #Keep the password re-entry form up
        password = passwordbox("Re-enter your password. " + errMsg, " ",)
        #Ask for the password, showing an error message is applicable

        if(password == createEntries[1]): #If re-entry is the same
            #Write account info to file hashed
            hVal = hashlib.md5(userPass.encode()) # Encode the password
            usersData[userName] = [hVal.hexdigest(),0]
            with open("users.txt", "w") as destination:
                destination.write(str(usersData))
            print("Write to file")
            showLogon()
            break
        elif(password is None): #If cancel was clicked
            logonCreate() #Re-start account creation
        else: #If the passwords do not match
            errMsg = ("Entered password is not the same.") #Create error message

def logonCheckInfo(loginEntries): #Check login info from user
    rightName = False #Correct info or not
    rightPass = False

    with open("users.txt", "r") as source:
        usersData = eval(source.read()) #eval used to read into dictionary

    enteredName = loginEntries[0]
    enteredPass = loginEntries[1]
    hVal = hashlib.md5(enteredPass.encode()) # Encode the entered password
    enteredPass = hVal.hexdigest()

    if(enteredName in usersData):
        storedPass = usersData[enteredName][0]
        rightName = True
        if(enteredPass == storedPass): #Check entered pass against stored pass
            rightPass = True #If they're the same

    return(rightName, rightPass)

def showLogon(userName): #Launch the login screen
    attempts = 3
    detailsCorrect = False
    dataExists = logonCheckFirst("users.txt")

    #dataExists = True ###Uncomment to ignore first run check -------------------

    if (dataExists == True): #If this isn't the first run
        createAccount = ccbox(msg="Do you want to make a new account?",title="",choices=("yes","no")) #Account creation

        if (createAccount == True):
            logonCreate()

        loginHeader = ("Login")
        loginMsg = ("Enter your login information")
        loginFields = ["Username","Password"]

        while 1:
            loginEntries = multpasswordbox(loginMsg,loginHeader,loginFields,)

            if(loginEntries is None): #If cancel is clicked
                sys.exit(0) #Close the program
            else:
                #Check username + password against stored values
                rightName, rightPass = logonCheckInfo(loginEntries)

                if(rightName == True and rightPass == True): #Right name & pass
                    showHub(loginEntries[0]) #Show the game hub - sending the username
                elif(rightName == True): #Just right name
                    attempts -= 1

                    if(attempts > 0):
                        loginMsg = ("Incorrect details - ") + str(attempts) + (" attempts left.")
                    else:
                        msgbox("You have run out of login attempts.")
                        break
                else:
                    loginMsg = ("Username does not exist.")

            #showHub("Haydn") #Uncomment to skip login entry

    else: #If this is the first run
        logonCreate() #Get the user to create an account

showLogon("") #Start