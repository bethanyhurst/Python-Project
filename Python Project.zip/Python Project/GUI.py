##http://easygui.sourceforge.net/tutorial.html - For using easyGUI

from easygui import *
import sys
import hashlib
import string
import random

def checkNum(char): #Checks if a given string is a number
    try:
        char = int(char) #Try to convert the string into an integer
        return(True) #If it was successful return true
    except:
        return(False) #If not return false

def genMessage(minLen, maxLen): #Picks a random word between a certain length
    with open("words.txt") as source: #Open the file of words
        words = [line.strip() for line in source if len(line) in range(minLen, maxLen)] #Put the words between the given numbers into a list

    message = random.choice(words) #Pick a random word
    return(message) #Return the word

def hangmanDraw(userName, question, state, numOfAttempts, score): #Updates the hangman image
    attemptsLeft = ("\nYou have " + str(numOfAttempts) + " attempts left") #The messages to show the user
    scoreCurrent = ("\nYour current score is " + str(score))
    imageCurrent = ("State" + str(state) + ".png")
    userInput = enterbox(msg=question + attemptsLeft + scoreCurrent, title="Hangman quiz", image=imageCurrent)
    #Display the info and get an answer from the user
    if(userInput == None): #If the cancel button or the x is clicked
        showHub(userName) #Go back to the hub

    return(userInput) #Return the answer

def checkAnswer(userName, score, state, question, message, codedMessage, decrypt): #checks all answers
    numOfAttempts = 3 #Chances the user has the answerr the question right

    while numOfAttempts > 0: #Keeps asking until no more attempts are left
        response = hangmanDraw(userName, question,state, numOfAttempts, score) #Get a response from the user

        if ((decrypt == True and response == message) or (decrypt == False and response == codedMessage)):#If the answer is right
            ########print("Well done!")
            score += 1 #Add one to their score
            break #Exit the loop
        else: #Their answer is wrong
            ########print("Incorrect! Try again.")
            numOfAttempts -= 1 #One less attempt

    if (numOfAttempts <= 0): #If they ran out off attempts
        ########print("Too many wrong answers") #No chances left - next question
        state += 1 #Move the hangman to the next state

    return(state, score) #Return the new score and state

def fencePost(userName, state, score):
    decrypt = random.choice([True, False]) #Pick decode or encode
    message = genMessage(8, 15) #Pick a word
    fenceHeight = random.randint(4,10) #Pick a fencepost height
    codedMessage = ""

    for k in range(fenceHeight):
        codedMessage += message[k: : fenceHeight]

    if(decrypt == True):
        question = ("Decode the following message using the fencepost cipher with height " + str(fenceHeight) + ": " + codedmessage)
    else:
        question = ("Encode the following message using the fencepost cipher with height " + str(fenceHeight) + ": " + message)

    state, score = checkAnswer(userName, score, state, question, message, codedmessage, decrypt)
    return(state, score)

def caesar(userName, state, score): #Caesar question
    alphabet = string.ascii_lowercase #Lower case alphabet
    alphLen = len(alphabet) #Holds the length of the alphabet
    message = genMessage(5, 15) #Get the message to use
    shift = random.randint(1, 25) #Choose a shift
    decrypt = random.choice([True, False]) #Choose encode or decode

    if decrypt == False: #Encode was chosen
        question = ("Encrypt this message, using the caesar cipher, shift ") + str(shift) + ": " + message
    else: #Decode was chosen
        shift *= -1 #Negate the shift
        question = ("Decrypt this message, using the caesar cipher, shift ") + str(shift) ####

    codedMessage = []

    for char in message: #Go through each character in the message
        if char in alphabet: #If the character is a letter
            charPos = alphabet.index(char) #Get the position of the character in the alphabet

        newCharPos = (charPos + shift) % alphLen #Get the shifted position of the character
        codedMessage.append(alphabet[newCharPos]) #Add the shifted character to the ciphertext

    if decrypt == True: #If it's a decrypt question
        question += (": ") + "".join(codedMessage) #Add the ciphertext to the question

    ########print(question)
    ########print(message) ####Shows answers
    ########print("".join(codedMessage)) ####
    state, score = checkAnswer(userName, score, state, question, message, "".join(codedMessage), decrypt) #Get and check their answer
    return(state, score) #Return the updated score and state

def vigenereTable(): #Function to fill a list with lists of the alphabet with different shifts
    table = []
    for i in range(26): #Make the table have 26 items
        table.append([])

    for row in range(26): #For each letter in the alphabet
        for column in range(26): #Create a list of a shifted alphabet beginning with the current letter
            if (row + 65) + column > 90:
                # moving back to A after Z
                # after first row, each letter will shift left by one position compared to row above it
                table[row].append(chr((row+65) + column - 26)) #Add the letter to the table
            else:
                # after first row, each letter will shift left by one position compared to row above it
                character = chr((row+65)+column)
                table[row].append(character) #Add the letter to the table

    return(table) #Return the table

def vigenereEncryption(message, mappedKey): #Encrypts the message using the key
    table = vigenereTable() #Get a table of all the shifted alphabets
    codedMessage = ""

    for i in range(len(message)): #For each character in the message

        if message[i] == chr(32): #If the character is a space
            # ignoring space
            codedMessage += " " #Add a space to the ciphertext
        else:
            # getting element at specific index of table
            row = ord(message[i])-65 #The row in the table of the encoded character
            column = ord(mappedKey[i]) - 65 #The column in the table
            codedMessage += table[row][column] #Add the encoded character to the ciphertext

    #(codedMessage) ########Show answer
    return(codedMessage)

def vigenereMessageKey(): #Generates the message & key & maps it to the message
    msg = genMessage(5,15).upper() #get a message
    key = genMessage(3,8).upper() #Get a key
    #print(msg) ########Show message
    # variable to store mapped key
    keyMap = "" #The key repeated for the same number of characters as the message
    j=0 #Holds the place of the current key character

    for i in range(len(msg)): #Counts through each letter in the message

        if ord(msg[i]) == 32: #ord() gets the unicode code for the character
            #If the current letter is a space
            keyMap += " " #A space lined up with each space in the message
        else:

            if j < len(key): #Count through the letters in the key
                keyMap += key[j] #Add the character to the key map
                j += 1 #Move to next letter
            else:
                j = 0 #Go back to the start of the key
                keyMap += key[j] #Add the character to the key map
                j += 1 #Move to next letter
    ########print(keyMap)
    return msg, keyMap, key #Return the obtained values

def vigenere(userName, state, score): #Vigenere question
    decrypt = random.choice([True, False]) #Choose encode or decode
    message, mappedKey, key = vigenereMessageKey() #Get the message and the key
    codedMessage = vigenereEncryption(message, mappedKey) #Encrypt the message

    if decrypt == False: #Encrypt
        question = ("Encrypt the following message, using the vigenere cipher with " + key + " as the key: " + message)

    else: #Decrypt
        question = ("Decrypt the following message, using the vigenere cipher with " + key + " as the key: " + codedMessage)

    ########print(question)
    state, score = checkAnswer(userName, score, state, question, message, codedMessage,decrypt)
    return(state, score)

def logonCheckFirst(fileName):
    try: #Check if the program has been run before
        reading = open(fileName) #Try to open the accounts file
        dataExists = True #The file exists - the program has been run before
    except:
        dataExists = False #The file doesn't exist - this is the first run of the program
    return(dataExists)

def logonPassStrength(password): #Finds the number of each type of character in the given password
    numChar = 0
    numLet = 0
    numLetUpp = 0
    numLetLow = 0
    numNum = 0
    numSym = 0
    listAlphabet = list(string.ascii_letters)
    listAlphabetLow = list(string.ascii_lowercase)
    listAlphabetUpp = list(string.ascii_uppercase)

    for char in password: #Go through each character in the password
        if(checkNum(char) == True): #If the character is a number
            numNum += 1
        elif(char in listAlphabet): #if the character is a letter
            if(char in listAlphabetLow): #If it is lower case
                numLetLow += 1
            else: #it is upper case
                numLetUpp += 1
            numLet += 1
        else: #It is a symbol
            numSym += 1
        numChar += 1
    return(numChar,numLet,numLetLow,numLetUpp,numNum,numSym)

def logonCreate(): #Allow the user to create an account
    dataExists = logonCheckFirst("Users.txt")
    createHeader = ("Create your account") #Title of the page
    createMsg = ("Enter your chosen username and password.\n" +
    "\nYour password must be 9 characters or longer and contain one or more " +
    "symbol, number, upper case and lower case letter.") #Main message
    createFields = ["Username","Password"] #Entry fields
    createEntries = [] #Results given by the user
    errMsg = ""

    if(dataExists == True): #If there is a data file
        with open("users.txt") as source:
            usersData = eval(source.read()) #Read the data into a dictionary
    else:
        usersData = {} #If there isn't create an empty dictionary

    if(logonCheckFirst("bannedwords.txt") == True): #If there is a banned words list
        with open("bannedwords.txt") as source:
            bannedWords = [line.strip() for line in source] #Read the list into a list
    else:
        bannedWords = [] #If not make an empty one

    while 1: #Keep asking for entries until entered data is valid
        createEntries = multpasswordbox(createMsg + errMsg, createHeader, createFields) #Display fields and get entries back

        if(createEntries is None): #If cancel is clicked
            sys.exit(0) #Close the program
        else:
            userName = createEntries[0] #Their chosen username
            userPass = createEntries[1] #Their chosen password
            numChar,numLet,numLetLow,numLetUpp,numNum,numSym = logonPassStrength(userPass) #Strength check
            bannedWord = False

            for word in bannedWords: #Check for banned words in the username
                if(word in userName):
                    bannedWord = True #Banned word present

            if(userPass == ""): #No password entered
                errMsg = ("\n\nNeed to enter a password.")
            elif(userName == ""): #No username entered
                errMsg = ("\n\nNeed to enter a username.")
            elif(usersData.__contains__(userName)): #Username already used
                errMsg = ("\n\nUsername already in use.")
            elif(numChar < 9): #Short password
                errMsg = ("\n\nPassword too short")
            elif(numLetLow == 0):
                errMsg = ("\n\nNo lowercase letters in the password.")
            elif(numLetUpp == 0):
                errMsg = ("\n\nNo uppercase letters in the password.")
            elif(numNum == 0):
                errMsg = ("\n\nNo numbers in the password.")
            elif(numSym == 0):
                errMsg = ("\n\nNo symbols in the password.")
            elif(bannedWord == True):
                errMsg = ("\n\nUsername contains a banned word.")
            else: #If all data is valid
                break

    errMsg = ""

    while 1: #Keep the password re-entry form up
        password = passwordbox("Re-enter your password. " + errMsg, " ",)
        #Ask for the password, showing an error message is applicable

        if(password == createEntries[1]): #If re-entry is the same
            #Write account info to file hashed
            hVal = hashlib.md5(userPass.encode()) # Encode the password
            usersData[userName] = [hVal.hexdigest(),0]
            with open("users.txt", "w") as destination:
                destination.write(str(usersData))
            ########print("Write to file")
            showLogon(userName)
            break
        elif(password is None): #If cancel was clicked
            logonCreate() #Re-start account creation
        else: #If the passwords do not match
            errMsg = ("Entered password is not the same.") #Create error message

def logonCheckInfo(loginEntries): #Check login info from user
    rightName = False #Correct info or not
    rightPass = False

    with open("users.txt", "r") as source:
        usersData = eval(source.read()) #eval used to read into dictionary

    enteredName = loginEntries[0] #The username the user typed in
    enteredPass = loginEntries[1] #The password the user types in
    hVal = hashlib.md5(enteredPass.encode()) #Hash the entered password
    enteredPass = hVal.hexdigest()

    if(enteredName in usersData): #If the username is valid
        storedPass = usersData[enteredName][0] #Get the corresponding password
        rightName = True #The username is right
        if(enteredPass == storedPass): #Check entered pass against stored pass
            rightPass = True #If they're the same

    return(rightName, rightPass) #Return the results

def showScore(userName): #Launch the scoreboard
    dataExists = logonCheckFirst("Users.txt")
    scores = []
    users = []

    for i in range(0,10): #Make the lists the right size
        scores.append(0)
        users.append("---")
    ########print(scores)

    if(dataExists == True): #If there is data
        with open("users.txt") as source: #Open the data file
            usersData = eval(source.read()) #Put the data into a dictionary

        for key,data in usersData.items(): #Go through each item in the dictionary
            ########print(data[1])
            if(data[1] > scores[0]): #If the current score is greater than the loswest
                scores[0] = data[1] #Replace the lowest score
                scores.sort() #Sort the list of scores
                users[0] = key #Add the new user to the list & remove the lowest score's user
                scoreLoc = scores.index(data[1]) #Get the index of the new score

                for i in range(0,scoreLoc): #Move the user to the same index as their score
                    pos2 = users[i+1] #Swap in groups of 2 - like a bubble sort
                    users[i+1] = users[i]
                    users[i] = pos2

                users[scoreLoc] = key #Move the user to the same index as their score

        scores.sort(reverse=True) #Reverse both lists to display them properly
        users.reverse()

    msg = ""

    for i in range(0,10): #Put the lists into a format for the messagebox
        msg += "\n"+ users[i] + str(scores[i])

    ok = msgbox(msg, ok_button = "OK") #Display the messagebox with the scores

    if(ok == "OK"): #When the user clicks ok
        showHub(userName) #Go back to the hub
    else:
        exit(0)
    ########print(scores)

def showHangman(userName): #Launch hangman
    choice = ("Yes")

    while(choice == "Yes"): #Loop games until the user wants to stop (this prevents stack overflow vs calling the function again)
        ########print("Hangman")
        state = 0 #Holds the current state of the image
        score = 0 #Holds the user's score
        qTypes = [caesar, vigenere, fencePost] #The types of questions available and their function calls

        while(state < 12): #Loop to ask questions
            qType = random.choice(qTypes) #Choose a random type
            state, score = qType(userName, state, score) #Call the function of the question type

        dataExists = logonCheckFirst("Users.txt")
        if(dataExists == True):
            with open("users.txt") as source:
                usersData = eval(source.read())
            if(score > usersData[userName][1]): #If the current score is higher than the high score
                usersData[userName][1] = score #Replace it
                with open("users.txt", "w") as destination:
                    destination.write(str(usersData))

        endMsg = ("Want to play again?")
        choices = ["Yes", "No"]
        choice = buttonbox(msg=endMsg, choices=choices) #Ask if the user wants to play again

    showHub(userName) #Go back to the hub once the user doesn't want to continue

def showHub(userName): #Hub screen to choose a feature of the program
    functions = [showHangman,showScore,showLogon] #List of the functions to leaunch the different areas of the program
    choices=["Hangman", "Scoreboard", "Log out"] #List of the options given to the user
    selected = indexbox("What do you want to do?", choices=choices) #Display the options to the user and get their chosen one

    if(selected != None): #If the window isn't closed
        functions[selected](userName) #Run the chosen function
    else:
        exit(0) #Exit the program

def showLogon(userName): #Launch the login screen
    attempts = 3 #Number of logon attempts before the program closes
    detailsCorrect = False #Whether the entered details are correct
    dataExists = logonCheckFirst("users.txt") #Check if there is a data file

    #dataExists = True ###Uncomment to ignore first run check -------------------

    if (dataExists == True): #If this isn't the first run
        createAccount = ccbox(msg="Do you want to make a new account?",title="",choices=("yes","no")) #Account creation

        if (createAccount == True): #The user wants to create an account
            logonCreate()

        loginHeader = ("Login")
        loginMsg = ("Enter your login information")
        loginFields = ["Username","Password"]

        while 1:
            loginEntries = multpasswordbox(loginMsg,loginHeader,loginFields,) #Get login info from the user

            if(loginEntries is None): #If cancel is clicked
                sys.exit(0) #Close the program
            else:
                #Check username + password against stored values
                rightName, rightPass = logonCheckInfo(loginEntries)

                if(rightName == True and rightPass == True): #Right name & pass
                    showHub(loginEntries[0]) #Show the game hub - sending the username
                elif(rightName == True): #Just right name
                    attempts -= 1

                    if(attempts > 0): #If there are attempts left
                        loginMsg = ("Incorrect details - ") + str(attempts) + (" attempts left.")
                    else:
                        msgbox("You have run out of login attempts.")
                        break
                elif(loginEntries[0] == ""):
                    loginMsg("Enter your details")
                else:
                    loginMsg = ("Username does not exist.")

            #showHub("Haydn") #Uncomment to skip login entry

    else: #If this is the first run
        logonCreate() #Get the user to create an account

showLogon("") #Start the program